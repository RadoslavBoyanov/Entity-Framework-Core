﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-455JGR0\SQLEXPRESS01;Database=MusicHub;Trusted_Connection=True";
    }
}
