﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-455JGR0\SQLEXPRESS01;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
